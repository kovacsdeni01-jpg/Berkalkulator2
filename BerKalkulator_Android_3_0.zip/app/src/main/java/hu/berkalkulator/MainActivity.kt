package hu.berkalkulator

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.text.InputType
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var result: TextView
    private val p by lazy { getSharedPreferences("ber", Context.MODE_PRIVATE) }
    private val nf = NumberFormat.getNumberInstance(Locale("hu","HU")).apply { maximumFractionDigits=0 }

    private lateinit var base: EditText
    private lateinit var days: EditText
    private lateinit var aft: EditText
    private lateinit var ot: EditText
    private lateinit var bonus: EditText
    private lateinit var km: EditText
    private lateinit var kmrate: EditText
    private lateinit var children: EditText
    private lateinit var deductions: EditText

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun num(e:EditText)=e.text.toString().replace(" ","").replace(",",".").toDoubleOrNull()?:0.0
    private fun ft(v:Double)=nf.format(max(0.0,v))+" Ft"

    override fun onCreate(b:Bundle?) { super.onCreate(b); ui(); load(); calculate() }

    private fun title(t:String)=TextView(this).apply {
        text=t; textSize=20f; setTypeface(null,Typeface.BOLD); setTextColor(Color.rgb(20,70,115))
        setPadding(0,dp(18),0,dp(8))
    }
    private fun field(box:LinearLayout, name:String, value:String):EditText {
        box.addView(TextView(this).apply { text=name; textSize=14f; setTypeface(null,Typeface.BOLD); setPadding(0,dp(6),0,dp(2)) })
        return EditText(this).apply {
            textSize=18f; setSingleLine(); setText(value)
            inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12),0,dp(12),0)
            box.addView(this,LinearLayout.LayoutParams(-1,dp(50)))
        }
    }
    private fun card():LinearLayout=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(4),dp(16),dp(14)); setBackgroundColor(Color.WHITE)
        root.addView(this,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
    }

    private fun ui(){
        val s=ScrollView(this)
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(28)); setBackgroundColor(Color.rgb(245,247,250)) }
        s.addView(root); setContentView(s)

        root.addView(TextView(this).apply { text="BérKalkulátor"; textSize=30f; gravity=Gravity.CENTER; setTypeface(null,Typeface.BOLD); setTextColor(Color.rgb(15,55,90)); setPadding(0,dp(10),0,0) })
        root.addView(TextView(this).apply { text="Személyes havi bértervező"; textSize=16f; gravity=Gravity.CENTER; setTextColor(Color.DKGRAY); setPadding(0,0,0,dp(14)) })

        root.addView(title("📅 Aktuális hónap"))
        val a=card()
        base=field(a,"Bruttó alapbér","484700")
        days=field(a,"Ledolgozott munkanapok","21")
        aft=field(a,"Délutános napok","10")

        root.addView(title("⏱️ Túlóra és pótlék"))
        val b=card()
        ot=field(b,"Túlóra (óra, a napi +30 perc is ide számolható)","10.5")
        bonus=field(b,"Havi bónusz","60000")

        root.addView(title("🚗 Bejárás"))
        val c=card()
        km=field(c,"Egyirányú távolság (km)","30")
        kmrate=field(c,"Támogatás (Ft/km)","30")

        root.addView(title("👨‍👩‍👧‍👦 Kedvezmény és levonás"))
        val d=card()
        children=field(d,"Kedvezményezett gyermekek","3")
        deductions=field(d,"Letiltások száma","0")

        val calc=Button(this).apply { text="KISZÁMÍTÁS"; textSize=18f; setOnClickListener{calculate();save()} }
        root.addView(calc,LinearLayout.LayoutParams(-1,dp(58)).apply{bottomMargin=dp(10)})

        result=TextView(this).apply { textSize=17f; setTextColor(Color.rgb(20,65,110)); setBackgroundColor(Color.WHITE); setPadding(dp(18),dp(18),dp(18),dp(18)) }
        root.addView(result)
    }

    private fun calculate(){
        val b=num(base); val d=num(days); val a=num(aft); val overtime=num(ot)
        val bon=num(bonus); val dist=num(km); val rate=num(kmrate); val kids=num(children).toInt()
        val cnt=num(deductions).toInt().coerceAtLeast(0)
        val hourly=b/168.0
        val shift=hourly*4*a*0.30
        val otpay=hourly*overtime*1.50
        val gross=b+shift+otpay+bon
        val tbGross=gross*.185
        val family=when { kids>=3 -> 98775.0; kids==2 -> 98775.0; kids==1 -> 66000.0; else -> 0.0 }
        val tb=max(0.0,tbGross-family)
        val szja=0.0
        val net=max(0.0,gross-tb-szja)
        val travel= d*dist*2*rate
        val before=net+travel
        val protected=128797.0
        val pct=when(cnt){0->0.0;1->.33;else->.50}
        val maxDed=max(0.0,before-protected)
        val deduction=min(before*pct,maxDed)
        val transfer=before-deduction
        result.text="""VÁRHATÓ UTALÁS

${ft(transfer)}

Levonás nélkül: ${ft(before)}

Alapbér                 ${ft(b)}
Délutáni pótlék (30%)   ${ft(shift)}
Túlóra (50% pótlékkal)  ${ft(otpay)}
Bónusz                  ${ft(bon)}
Becsült bruttó         ${ft(gross)}

TB (18,5%)              -${ft(tbGross)}
Családi járulékkedv.    +${ft(family)}
Fizetendő TB            -${ft(tb)}
SZJA                    ${ft(szja)}
3 gyermek kedvezménye   ${ft(family)}

Bejárás                 +${ft(travel)}

Letiltások:             $cnt
Alkalmazott arány:      ${(pct*100).toInt()}%
Védett minimum:         ${ft(protected)}
Levonás:                -${ft(deduction)}

Megjegyzés:
A 21 munkanapos, 10 délutános augusztusi példa és a napi +30 perc túlóra alapértékként szerepel. Minden adat kézzel átírható."""
    }

    private fun save(){
        listOf("base" to base,"days" to days,"aft" to aft,"ot" to ot,"bonus" to bonus,"km" to km,"rate" to kmrate,"kids" to children,"ded" to deductions)
            .forEach{p.edit().putString(it.first,it.second.text.toString()).apply()}
    }
    private fun load(){
        base.setText(p.getString("base","484700")); days.setText(p.getString("days","21")); aft.setText(p.getString("aft","10"))
        ot.setText(p.getString("ot","10.5")); bonus.setText(p.getString("bonus","60000")); km.setText(p.getString("km","30"))
        kmrate.setText(p.getString("rate","30")); children.setText(p.getString("kids","3")); deductions.setText(p.getString("ded","0"))
    }
}
