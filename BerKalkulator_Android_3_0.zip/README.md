# BérKalkulátor 3.0
Telefonról felhőben buildelhető Android projekt.
A felület az Excel/bérpapír logikájára épül, havi tervezővel és manuális felülírással.
