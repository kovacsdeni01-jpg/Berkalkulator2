package hu.berkalkulator
import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

class MainActivity: Activity(){
 private lateinit var root:LinearLayout; private lateinit var out:TextView
 private lateinit var base:EditText; private lateinit var hours:EditText; private lateinit var days:EditText
 private lateinit var aft:EditText; private lateinit var pct:EditText; private lateinit var ot:EditText
 private lateinit var bonus:EditText; private lateinit var travel:EditText; private lateinit var kids:EditText
 private lateinit var deductions:EditText
 private val p by lazy{getSharedPreferences("ber",Context.MODE_PRIVATE)}
 private val nf=NumberFormat.getNumberInstance(Locale("hu","HU")).apply{maximumFractionDigits=0}
 private fun dp(x:Int)= (x*resources.displayMetrics.density).toInt()
 private fun n(e:EditText)=e.text.toString().replace(" ","").replace(",",".").toDoubleOrNull()?:0.0
 private fun money(x:Double)=nf.format(max(0.0,x))+" Ft"
 private fun title(s:String)=TextView(this).apply{text=s;textSize=19f;setTypeface(null,Typeface.BOLD);setTextColor(Color.rgb(20,75,125));setPadding(0,dp(15),0,dp(6))}
 private fun field(parent:LinearLayout,s:String,d:String):EditText{
   parent.addView(TextView(this).apply{text=s;textSize=15f;setTypeface(null,Typeface.BOLD);setPadding(0,dp(7),0,dp(3))})
   return EditText(this).apply{textSize=18f;setSingleLine();setText(d);inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
     setPadding(dp(14),dp(8),dp(14),dp(8));parent.addView(this,LinearLayout.LayoutParams(-1,dp(50)))}
 }
 override fun onCreate(b:Bundle?){super.onCreate(b);ui();load();calc()}
 private fun ui(){
   val sc=ScrollView(this);root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(10),dp(18),dp(28));setBackgroundColor(Color.rgb(245,247,250))}
   sc.addView(root);setContentView(sc)
   root.addView(TextView(this).apply{text="BÉRKALKULÁTOR 2.0";textSize=28f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(Color.rgb(15,55,90));setPadding(0,dp(10),0,0)})
   root.addView(TextView(this).apply{text="Személyes havi bértervező";textSize=16f;gravity=Gravity.CENTER;setPadding(0,0,0,dp(12))})
   fun sec(s:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(5),dp(14),dp(14));setBackgroundColor(Color.WHITE);root.addView(title(s));root.addView(this,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})}
   var x=sec("💼 Munkabér")
   base=field(x,"Bruttó alapbér (Ft)","484700");hours=field(x,"Havi munkaóra","168");days=field(x,"Munkanapok","21");aft=field(x,"Délutános műszakok","0");pct=field(x,"Délutáni pótlék (%)","30")
   x=sec("➕ Túlóra és egyéb");ot=field(x,"Túlóra (óra)","0");bonus=field(x,"Havi bónusz (Ft)","60000");travel=field(x,"Munkába járási támogatás (Ft)","0")
   x=sec("👨‍👩‍👧‍👦 Kedvezmény");kids=field(x,"Gyermekek száma","3")
   x=sec("⚖️ Levonás");deductions=field(x,"Levonások száma (0 / 1 / 2+)","0")
   root.addView(Button(this).apply{text="💰 FIZETÉS KISZÁMÍTÁSA";textSize=19f;setOnClickListener{calc();save()}},LinearLayout.LayoutParams(-1,dp(58)).apply{bottomMargin=dp(8)})
   root.addView(Button(this).apply{text="Alapértékek visszaállítása";setOnClickListener{defaults();calc();save()}},LinearLayout.LayoutParams(-1,dp(50)).apply{bottomMargin=dp(8)})
   out=TextView(this).apply{textSize=18f;setTextColor(Color.rgb(20,65,110));setBackgroundColor(Color.WHITE);setPadding(dp(18),dp(18),dp(18),dp(18))}
   root.addView(out)
 }
 private fun calc(){
   val b=n(base);val h=max(1.0,n(hours));val a=n(aft);val pr=n(pct)/100;val overtime=n(ot);val bon=n(bonus);val tr=n(travel);val k=n(kids).toInt().coerceIn(0,10);val d=n(deductions).toInt()
   val hourly=b/h;val shift=hourly*8*a*pr;val otp=hourly*overtime*1.5;val gross=b+shift+otp+bon
   val szja=gross*.15;val tb=gross*.185
   val family=when{k>=3->k*66000.0;k==2->80000.0;k==1->20000.0;else->0.0}
   val familySaving=minOf(family,szja+tb);val noDed=max(0.0,gross-szja-tb+familySaving)+tr
   val rate=when{d<=0->0.0;d==1->.33;else->.50};val ded=noDed*rate;val transfer=noDed-ded
   out.text="""VÁRHATÓ FIZETÉS
Alapbér:                 ${money(b)}
Délutáni pótlék:         ${money(shift)}
Túlóra:                  ${money(otp)}
Bónusz:                  ${money(bon)}
Bejárás:                +${money(tr)}
────────────────────────
Becsült bruttó:          ${money(gross)}
SZJA:                   -${money(szja)}
TB:                     -${money(tb)}
3 gyermek kedvezménye:  +${money(familySaving)}

LEVONÁS NÉLKÜLI UTALÁS:
${money(noDed)}

Levonások: $d
Alkalmazott arány: ${(rate*100).toInt()}%
Levonás:                -${money(ded)}

════════════════════════
VÁRHATÓ UTALÁS:
${money(transfer)}
════════════════════════

Órabér:                  ${money(hourly)}
Munkanapok:              ${n(days).toInt()}
Délutános műszak:        ${a.toInt()}
Túlóra:                  $overtime óra"""
 }
 private fun save(){p.edit().putString("base",base.text.toString()).putString("hours",hours.text.toString()).putString("days",days.text.toString()).putString("aft",aft.text.toString()).putString("pct",pct.text.toString()).putString("ot",ot.text.toString()).putString("bonus",bonus.text.toString()).putString("travel",travel.text.toString()).putString("kids",kids.text.toString()).putString("ded",deductions.text.toString()).apply()}
 private fun load(){base.setText(p.getString("base","484700"));hours.setText(p.getString("hours","168"));days.setText(p.getString("days","21"));aft.setText(p.getString("aft","0"));pct.setText(p.getString("pct","30"));ot.setText(p.getString("ot","0"));bonus.setText(p.getString("bonus","60000"));travel.setText(p.getString("travel","0"));kids.setText(p.getString("kids","3"));deductions.setText(p.getString("ded","0"))}
 private fun defaults(){base.setText("484700");hours.setText("168");days.setText("21");aft.setText("0");pct.setText("30");ot.setText("0");bonus.setText("60000");travel.setText("0");kids.setText("3");deductions.setText("0")}
}